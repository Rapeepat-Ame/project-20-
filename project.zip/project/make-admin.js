require('dotenv').config();
const { MongoClient } = require('mongodb');

const email = String(process.argv[2] || '').trim().toLowerCase();
const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/server_rental';
const dbName = process.env.MONGODB_DB || 'server_rental';

if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error('วิธีใช้: npm run make-admin -- อีเมลที่สมัครสมาชิกไว้');
  process.exit(1);
}

async function main() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const users = client.db(dbName).collection('users');
    const result = await users.updateOne({ email }, { $set: { role: 'admin' } });
    if (!result.matchedCount) {
      console.error(`ไม่พบบัญชี ${email} กรุณาสมัครสมาชิกผ่านหน้าเว็บก่อน`);
      process.exitCode = 1;
      return;
    }
    console.log(`ตั้งสิทธิ์ผู้ดูแลระบบให้ ${email} สำเร็จ`);
    console.log('ให้ออกจากระบบเว็บไซต์ แล้วเข้าสู่ระบบใหม่อีกครั้ง');
  } catch (error) {
    console.error('ดำเนินการไม่สำเร็จ:', error.message);
    process.exitCode = 1;
  } finally {
    await client.close();
  }
}

main();
