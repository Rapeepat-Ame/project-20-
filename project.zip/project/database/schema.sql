CREATE DATABASE IF NOT EXISTS server_rental
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE server_rental;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('member', 'admin') NOT NULL DEFAULT 'member',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS servers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(60) NOT NULL,
  cpu VARCHAR(100) NOT NULL,
  ram_gb INT UNSIGNED NOT NULL,
  storage_gb INT UNSIGNED NOT NULL,
  price_per_day DECIMAL(10,2) NOT NULL,
  description TEXT,
  is_available BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rentals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  server_id INT UNSIGNED NOT NULL,
  duration_days INT UNSIGNED NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  status ENUM('pending', 'active', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rentals_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_rentals_server FOREIGN KEY (server_id) REFERENCES servers(id)
);

INSERT INTO servers (name, category, cpu, ram_gb, storage_gb, price_per_day, description)
SELECT 'Starter VPS', 'VPS', '2 vCPU', 4, 80, 45.00, 'เหมาะสำหรับเว็บไซต์ขนาดเล็กและงานทดลอง'
WHERE NOT EXISTS (SELECT 1 FROM servers WHERE name = 'Starter VPS');

INSERT INTO servers (name, category, cpu, ram_gb, storage_gb, price_per_day, description)
SELECT 'Business VPS', 'VPS', '4 vCPU', 8, 160, 89.00, 'เหมาะสำหรับเว็บไซต์ที่มีผู้ใช้งานระดับกลาง'
WHERE NOT EXISTS (SELECT 1 FROM servers WHERE name = 'Business VPS');

INSERT INTO servers (name, category, cpu, ram_gb, storage_gb, price_per_day, description)
SELECT 'Compute Server', 'Dedicated', '8 Cores', 16, 500, 180.00, 'เหมาะสำหรับงานประมวลผลและระบบที่ต้องการทรัพยากรมากขึ้น'
WHERE NOT EXISTS (SELECT 1 FROM servers WHERE name = 'Compute Server');
