
function showCenteredConfirm({ title, message, confirmText = 'ยืนยัน', cancelText = 'ยกเลิก' }) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'custom-dialog-overlay';
    overlay.innerHTML = `
      <section class="custom-dialog" role="dialog" aria-modal="true" aria-labelledby="custom-dialog-title">
        <div class="custom-dialog-icon custom-dialog-icon-warning" aria-hidden="true">!</div>
        <h2 id="custom-dialog-title"></h2>
        <p class="custom-dialog-message"></p>
        <div class="custom-dialog-actions">
          <button type="button" class="button custom-dialog-cancel"></button>
          <button type="button" class="button custom-dialog-confirm"></button>
        </div>
      </section>`;
    overlay.querySelector('h2').textContent = title;
    overlay.querySelector('.custom-dialog-message').textContent = message;
    overlay.querySelector('.custom-dialog-cancel').textContent = cancelText;
    overlay.querySelector('.custom-dialog-confirm').textContent = confirmText;
    document.body.appendChild(overlay);
    const finish = value => { overlay.remove(); document.removeEventListener('keydown', onKey); resolve(value); };
    const onKey = event => { if (event.key === 'Escape') finish(false); };
    overlay.querySelector('.custom-dialog-cancel').addEventListener('click', () => finish(false));
    overlay.querySelector('.custom-dialog-confirm').addEventListener('click', () => finish(true));
    overlay.addEventListener('click', event => { if (event.target === overlay) finish(false); });
    document.addEventListener('keydown', onKey);
    overlay.querySelector('.custom-dialog-confirm').focus();
  });
}


function showCenteredMessage({ title, message, buttonText = 'ตกลง' }) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'custom-dialog-overlay';
    overlay.innerHTML = `<section class="custom-dialog" role="dialog" aria-modal="true"><div class="custom-dialog-icon" aria-hidden="true">✓</div><h2></h2><p class="custom-dialog-message"></p><div class="custom-dialog-actions"><button type="button" class="button custom-dialog-confirm"></button></div></section>`;
    overlay.querySelector('h2').textContent = title;
    overlay.querySelector('.custom-dialog-message').textContent = message;
    overlay.querySelector('button').textContent = buttonText;
    document.body.appendChild(overlay);
    const close = () => { overlay.remove(); document.removeEventListener('keydown', onKey); resolve(); };
    const onKey = event => { if (event.key === 'Escape') close(); };
    overlay.querySelector('button').addEventListener('click', close);
    overlay.addEventListener('click', event => { if (event.target === overlay) close(); });
    document.addEventListener('keydown', onKey);
    overlay.querySelector('button').focus();
  });
}

const THB_PER_USD = 36;

function updateCartCount() {
  let cart = [];
  try {
    const saved = JSON.parse(localStorage.getItem('serverRentalCart') || '[]');
    cart = Array.isArray(saved) ? saved : [];
  } catch { cart = []; }
  const count = cart.reduce((sum, item) => sum + Math.max(1, Number(item.quantity) || 1), 0);
  document.querySelectorAll('#cart-count').forEach(element => { element.textContent = String(count); });
}
window.addEventListener('storage', event => { if (event.key === 'serverRentalCart') updateCartCount(); });

function getCurrency() {
  return localStorage.getItem('serverRentalCurrency') === 'USD'
    ? 'USD'
    : 'THB';
}

function money(value) {
  const currency = getCurrency();
  const amount = Number(value) || 0;
  const convertedAmount =
    currency === 'USD' ? amount / THB_PER_USD : amount;

  return new Intl.NumberFormat(
    currency === 'THB' ? 'th-TH' : 'en-US',
    {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }
  ).format(convertedAmount);
}

const escapeHtml = value =>
  String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);

function formatDate(value) {
  if (!value) return '-';

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return '-';

  return date.toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

async function loadAccount() {
  const target = document.querySelector('#account-area');
  if (!target) return;

  try {
    const response = await fetch('/api/me');
    if (!response.ok) throw new Error('โหลดบัญชีไม่สำเร็จ');

    const data = await response.json();

    if (data.user) {
      target.innerHTML = `
        <span class="welcome-user">
          สวัสดี ${escapeHtml(data.user.name)}
        </span>
        ${
          data.user.role === 'admin'
            ? '<a class="button button-outline" href="/admin.html">จัดการระบบ</a>'
            : ''
        }
        <button class="button button-outline" id="logout-button" type="button">
          ออกจากระบบ
        </button>
      `;

      document.querySelector('#logout-button')
        ?.addEventListener('click', async () => {
          try {
            await fetch('/api/logout', { method: 'POST' });
          } finally {
            location.href = '/';
          }
        });
    } else {
      target.innerHTML = `
        <a class="button button-outline" href="/login.html">
          เข้าสู่ระบบ
        </a>
      `;
    }
  } catch {
    target.innerHTML = `
      <a class="button button-outline" href="/login.html">
        เข้าสู่ระบบ
      </a>
    `;
  }
}

async function loadRentals() {
  const list = document.querySelector('#rental-list');
  if (!list) return;

  try {
    const meResponse = await fetch('/api/me');
    const me = await meResponse.json();

    if (!me.user) {
      list.innerHTML = `
        <p class="error">
          กรุณาเข้าสู่ระบบเพื่อดูรายการเช่า
        </p>
      `;
      return;
    }

    const response = await fetch('/api/my-rentals');

    if (!response.ok) {
      throw new Error('โหลดรายการเช่าไม่สำเร็จ');
    }

    const rentals = await response.json();

    if (!rentals.length) {
      list.innerHTML = '<p>คุณยังไม่มีรายการเช่า Server</p>';
      return;
    }

    const statusLabels = {
      pending: 'รอการยืนยัน',
      active: 'กำลังใช้งาน',
      completed: 'เสร็จสิ้น',
      cancelled: 'ยกเลิกแล้ว'
    };

    list.innerHTML = rentals.map(rental => {
      const displayStatus = rental.status === 'pending' && rental.payment_status === 'paid'
        ? 'active'
        : rental.status;
      const status = statusLabels[displayStatus] || displayStatus;

      const canCancel =
        displayStatus === 'pending' ||
        displayStatus === 'active';

      const canExtend = displayStatus === 'active';

      return `
        <article class="rental-card">
          <div class="rental-card-top">
            <div class="rental-server-title">
              <span class="rental-server-label">SERVER ที่เช่า</span>
              <h3>${escapeHtml(rental.server_name || 'Server')}</h3>
              <span class="rental-server-id">รหัส Server: ${escapeHtml(rental.server_id ?? '-')}</span>
            </div>
            <span class="rental-status status-${escapeHtml(displayStatus)}">
              ${escapeHtml(status)}
            </span>
          </div>

          <div class="rental-details">
            <p><span>หมายเลขรายการเช่า</span><strong>#${escapeHtml(rental.id)}</strong></p>
            <p><span>ระยะเวลาเช่า</span><strong>${Number(rental.duration_days) || 0} วัน</strong></p>
            <p><span>วันที่ทำรายการ</span><strong>${escapeHtml(formatDate(rental.created_at))}</strong></p>
            <p><span>วันหมดอายุ</span><strong>${escapeHtml(formatDate(rental.expires_at))}</strong></p>
            ${rental.payment_status === 'paid' ? `<p><span>การชำระเงิน</span><strong class="payment-paid">ชำระแล้ว · ${rental.payment_method === 'paypal' ? 'PayPal' : rental.payment_method === 'mastercard' ? 'Mastercard' : 'ไม่ระบุ'}</strong></p>` : ''}
          </div>

          <div class="price-line">
            <strong>${money(rental.total_price)}</strong>
            <span>ยอดรวม</span>
          </div>

          ${
            canExtend
              ? `
                <div class="rental-actions">
                  <label>
                    ต่อเวลาอีก (วัน)
                    <input
                      class="extension-days"
                      data-id="${rental.id}"
                      type="number"
                      min="1"
                      max="3650"
                      step="1"
                      value="7"
                      inputmode="numeric"
                      aria-label="จำนวนวันที่ต้องการต่อเวลา"
                    >
                    <small class="extension-estimate" data-id="${rental.id}">ยอดเพิ่มโดยประมาณ: ${money((Number(rental.total_price) || 0) / Math.max(1, Number(rental.duration_days) || 1) * 7)}</small>
                  </label>

                  <button
                    class="button"
                    type="button"
                    data-action="extend"
                    data-id="${rental.id}">
                    ต่อเวลาการเช่า
                  </button>
                </div>
              `
              : ''
          }

          ${
            canCancel
              ? `
                <div class="rental-actions">
                  <button
                    class="button button-outline"
                    type="button"
                    data-action="cancel"
                    data-id="${rental.id}">
                    ยกเลิกการเช่า
                  </button>
                </div>
              `
              : ''
          }
        </article>
      `;
    }).join('');

    // ผูกปุ่มหลังจากสร้างรายการเช่าแล้ว
    list.querySelectorAll('[data-action="cancel"]')
      .forEach(button => {
        button.addEventListener('click', () => {
          cancelRental(button.dataset.id, button);
        });
      });

    // คำนวณยอดต่อเวลาใหม่ทันทีเมื่อผู้ใช้เปลี่ยนจำนวนวัน
    list.querySelectorAll('.extension-days').forEach(input => {
      const id = input.dataset.id;
      const estimate = list.querySelector(`.extension-estimate[data-id="${id}"]`);
      const rental = rentals.find(item => String(item.id) === String(id));
      const dailyRate = (Number(rental?.total_price) || 0) / Math.max(1, Number(rental?.duration_days) || 1);

      const updateEstimate = () => {
        const days = Number(input.value);
        const valid = Number.isInteger(days) && days >= 1 && days <= 3650;
        if (estimate) {
          estimate.textContent = valid
            ? `ยอดเพิ่มโดยประมาณ: ${money(dailyRate * days)}`
            : 'กรุณากรอกจำนวนวัน 1–3650 วัน';
        }
      };
      input.addEventListener('input', updateEstimate);
      input.addEventListener('change', updateEstimate);
    });

    list.querySelectorAll('[data-action="extend"]')
      .forEach(button => {
        button.addEventListener('click', () => {
          const input = list.querySelector(
            `.extension-days[data-id="${button.dataset.id}"]`
          );
          const days = Number(input?.value);
          if (!Number.isInteger(days) || days < 1 || days > 3650) {
            showCenteredMessage({ title: 'จำนวนวันไม่ถูกต้อง', message: 'กรุณากรอกจำนวนวันตั้งแต่ 1 ถึง 3650 วัน' });
            input?.focus();
            return;
          }
          extendRental(button.dataset.id, days, button);
        });
      });
  } catch (error) {
    console.error(error);

    list.innerHTML = `
      <p class="error">
        โหลดรายการเช่าไม่สำเร็จ กรุณาลองใหม่อีกครั้ง
      </p>
    `;
  }
}

async function readApiResponse(response) {
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || 'ดำเนินการไม่สำเร็จ');
  }

  return data;
}

async function cancelRental(id, button) {
  const confirmed = await showCenteredConfirm({
    title: 'ยืนยันการยกเลิก',
    message: 'คุณต้องการยกเลิกรายการเช่านี้ใช่หรือไม่?\nการยกเลิกอาจทำให้ไม่สามารถใช้งาน Server ต่อได้',
    confirmText: 'ยืนยันยกเลิก',
    cancelText: 'กลับไป'
  });
  if (!confirmed) return;

  button.disabled = true;

  try {
    const response = await fetch(
      `/api/my-rentals/${encodeURIComponent(id)}/cancel`,
      { method: 'POST' }
    );

    const data = await readApiResponse(response);

    await showCenteredMessage({ title: 'ยกเลิกการเช่าสำเร็จ', message: data.message || 'รายการเช่านี้ถูกยกเลิกเรียบร้อยแล้ว' });
    await loadRentals();
  } catch (error) {
    await showCenteredMessage({ title: 'ยกเลิกการเช่าไม่สำเร็จ', message: error.message || 'ไม่สามารถยกเลิกรายการเช่าได้ กรุณาลองใหม่' });
    button.disabled = false;
  }
}

async function extendRental(id, durationDays, button) {
  if (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 3650) {
    await showCenteredMessage({ title: 'ระยะเวลาไม่ถูกต้อง', message: 'กรุณากรอกจำนวนวันตั้งแต่ 1 ถึง 3650 วัน' });
    return;
  }
  if (button.dataset.processing === 'true') return;

  const confirmed = await showCenteredConfirm({
    title: 'ต่อเวลาและไปชำระเงิน',
    message: `ต้องการต่อเวลาการเช่าอีก ${durationDays} วันใช่หรือไม่?\nระบบจะสร้างรายการชำระเงิน และจะต่อเวลาเมื่อยืนยันชำระเงินแล้ว`,
    confirmText: 'ไปชำระเงิน',
    cancelText: 'กลับไป'
  });
  if (!confirmed) return;

  button.dataset.processing = 'true';
  button.disabled = true;

  try {
    const response = await fetch(
      `/api/my-rentals/${encodeURIComponent(id)}/extend-payment`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ duration_days: durationDays })
      }
    );
    const data = await readApiResponse(response);
    location.href = `/checkout.html?payment_id=${encodeURIComponent(data.payment_id)}`;
  } catch (error) {
    await showCenteredMessage({ title: 'สร้างรายการชำระเงินไม่สำเร็จ', message: error.message || 'กรุณาลองใหม่อีกครั้ง' });
    button.dataset.processing = 'false';
    button.disabled = false;
  }
}

function refreshRentalPrices() {
  loadRentals();
}

document.querySelector('#currency-select')
  ?.addEventListener('change', event => {
    const currency =
      event.target.value === 'USD' ? 'USD' : 'THB';

    localStorage.setItem('serverRentalCurrency', currency);
    refreshRentalPrices();
  });

const currencySelect = document.querySelector('#currency-select');

if (currencySelect) {
  currencySelect.value = getCurrency();
}

updateCartCount();
loadAccount();
loadRentals();
