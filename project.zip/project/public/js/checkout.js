(() => {
  const params = new URLSearchParams(location.search);
  const paymentId = Number(params.get('payment_id'));
  const state = document.querySelector('#checkout-state');
  const content = document.querySelector('#checkout-content');
  const form = document.querySelector('#payment-form');
  const payButton = document.querySelector('#pay-button');
  const cancelButton = document.querySelector('#cancel-button');
  const message = document.querySelector('#form-message');
  let payment;

  const THB_PER_USD = 36;
  const currency = localStorage.getItem('serverRentalCurrency') === 'USD' ? 'USD' : 'THB';
  const money = value => {
    const amount = currency === 'USD' ? Number(value) / THB_PER_USD : Number(value);
    return new Intl.NumberFormat(currency === 'THB' ? 'th-TH' : 'en-US', {
      style: 'currency', currency, minimumFractionDigits: 2, maximumFractionDigits: 2
    }).format(amount || 0);
  };

  async function readJson(response) {
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || 'เกิดข้อผิดพลาด กรุณาลองใหม่');
    return data;
  }

  function showPayment(data) {
    payment = data;
    state.hidden = true;
    content.hidden = false;
    document.querySelector('#payment-id').textContent = `#${data.id}`;
    document.querySelector('#server-name').textContent = data.server_name;
    document.querySelector('#duration').textContent = `${data.duration_days} วัน`;
    document.querySelector('#total-price').textContent = money(data.total_price);

    const statusNames = {
      pending: 'รอชำระเงิน', processing: 'กำลังดำเนินการ', paid: 'ชำระแล้ว',
      cancelled: 'ยกเลิกแล้ว', expired: 'หมดอายุ'
    };
    document.querySelector('#payment-status').textContent = statusNames[data.status] || data.status;

    if (data.status !== 'pending') {
      payButton.disabled = true;
      cancelButton.textContent = data.status === 'paid' ? 'ดูรายการเช่าของฉัน' : 'กลับไปเลือก Server';
      cancelButton.href = data.status === 'paid' ? '/rentals.html' : '/';
      if (data.status === 'paid') {
        message.style.color = '#067647';
        message.textContent = 'รายการนี้ชำระสำเร็จแล้ว';
      } else {
        message.textContent = 'รายการนี้ไม่สามารถชำระเงินต่อได้ กรุณากลับไปเลือก Server ใหม่';
      }
    }
  }

  async function loadPayment() {
    if (!Number.isInteger(paymentId) || paymentId < 1) {
      state.textContent = 'ไม่พบหมายเลขรายการชำระเงิน กรุณากลับไปเลือก Server';
      return;
    }
    try {
      const data = await readJson(await fetch(`/api/payments/${paymentId}`));
      showPayment(data);
    } catch (error) {
      state.textContent = error.message;
      if (error.message.includes('เข้าสู่ระบบ')) {
        location.href = `/login.html?message=${encodeURIComponent('กรุณาเข้าสู่ระบบก่อนชำระเงิน')}`;
      }
    }
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!payment || payment.status !== 'pending') return;
    const selected = form.querySelector('input[name="payment_method"]:checked');
    if (!selected) {
      message.textContent = 'กรุณาเลือกช่องทางชำระเงิน';
      return;
    }
    payButton.disabled = true;
    message.style.color = '#697386';
    message.textContent = 'กำลังยืนยันการชำระเงิน...';
    try {
      const result = await readJson(await fetch(`/api/payments/${paymentId}/confirm-demo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_method: selected.value })
      }));
      message.style.color = '#067647';
      message.textContent = `${result.message} กำลังไปหน้ารายการเช่า...`;
      document.querySelector('#payment-status').textContent = 'ชำระแล้ว';
      setTimeout(() => { location.href = '/rentals.html'; }, 900);
    } catch (error) {
      message.style.color = '#b42318';
      message.textContent = error.message;
      payButton.disabled = false;
      await loadPayment();
    }
  });

  cancelButton.addEventListener('click', async event => {
    if (!payment || payment.status !== 'pending') return;
    event.preventDefault();
    cancelButton.style.pointerEvents = 'none';
    try {
      await fetch(`/api/payments/${paymentId}/cancel-demo`, { method: 'POST' });
    } finally {
      location.href = '/';
    }
  });

  loadPayment();
})();
