
const THB_PER_USD = 36;

function getCurrency() {
    return localStorage.getItem("serverRentalCurrency") || "THB";
}

function formatMoney(thbValue) {
    const currency = getCurrency();
    const amount = Number(thbValue) || 0;

    return new Intl.NumberFormat(
        currency === "THB" ? "th-TH" : "en-US",
        {
            style: "currency",
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    ).format(currency === "USD" ? amount / THB_PER_USD : amount);
}

document.addEventListener("DOMContentLoaded", () => {
    const selector = document.getElementById("currency-switch");

    if (!selector) return;

    selector.value = getCurrency();

    selector.addEventListener("change", () => {
        localStorage.setItem(
            "serverRentalCurrency",
            selector.value
        );

        location.reload();
    });
});
