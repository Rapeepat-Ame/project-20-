
function showCenteredConfirm({ title, message, confirmText = 'ยืนยัน', cancelText = 'ยกเลิก' }) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'custom-dialog-overlay';
    overlay.innerHTML = `
      <section class="custom-dialog" role="dialog" aria-modal="true" aria-labelledby="custom-dialog-title">
        <div class="custom-dialog-icon" aria-hidden="true">✓</div>
        <h2 id="custom-dialog-title"></h2>
        <p class="custom-dialog-message"></p>
        <div class="custom-dialog-actions">
          <button type="button" class="button custom-dialog-cancel"></button>
          <button type="button" class="button custom-dialog-confirm"></button>
        </div>
      </section>`;
    overlay.querySelector('h2').textContent = title;
    overlay.querySelector('.custom-dialog-message').textContent = message;
    overlay.querySelector('.custom-dialog-cancel').textContent = cancelText;
    overlay.querySelector('.custom-dialog-confirm').textContent = confirmText;
    document.body.appendChild(overlay);
    const finish = value => { overlay.remove(); document.removeEventListener('keydown', onKey); resolve(value); };
    const onKey = event => { if (event.key === 'Escape') finish(false); };
    overlay.querySelector('.custom-dialog-cancel').addEventListener('click', () => finish(false));
    overlay.querySelector('.custom-dialog-confirm').addEventListener('click', () => finish(true));
    overlay.addEventListener('click', event => { if (event.target === overlay) finish(false); });
    document.addEventListener('keydown', onKey);
    overlay.querySelector('.custom-dialog-confirm').focus();
  });
}


const THB_PER_USD = 36;
const CART_KEY = 'serverRentalCart';

function updateCartCount() {
  let cart = [];
  try {
    const saved = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
    cart = Array.isArray(saved) ? saved : [];
  } catch { cart = []; }
  const count = cart.reduce((sum, item) => sum + Math.max(1, Number(item.quantity) || 1), 0);
  document.querySelectorAll('#cart-count').forEach(element => {
    element.textContent = String(count);
    element.hidden = false;
  });
  return count;
}

window.addEventListener('storage', event => {
  if (event.key === CART_KEY) updateCartCount();
});

function getCurrency() {
  return localStorage.getItem('serverRentalCurrency') === 'USD'
    ? 'USD'
    : 'THB';
}

function money(value) {
  const currency = getCurrency();
  const amount = Number(value) || 0;
  const convertedAmount =
    currency === 'USD' ? amount / THB_PER_USD : amount;

  return new Intl.NumberFormat(
    currency === 'THB' ? 'th-TH' : 'en-US',
    {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }
  ).format(convertedAmount);
}

const escapeHtml = value =>
  String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);

async function loadAccount() {
  const target = document.querySelector('#account-area');
  if (!target) return;

  try {
    const response = await fetch('/api/me');
    if (!response.ok) throw new Error('โหลดบัญชีไม่สำเร็จ');

    const data = await response.json();

    if (data.user) {
      target.innerHTML = `
        <span class="welcome-user">
          สวัสดี ${escapeHtml(data.user.name)}
        </span>

        ${
          data.user.role === 'admin'
            ? '<a class="button button-outline" href="/admin.html">จัดการระบบ</a>'
            : ''
        }

        <button
          class="button button-outline"
          id="logout-button"
          type="button"
        >
          ออกจากระบบ
        </button>
      `;

      document.querySelector('#logout-button')
        ?.addEventListener('click', async () => {
          try {
            await fetch('/api/logout', { method: 'POST' });
          } finally {
            location.href = '/';
          }
        });
    } else {
      target.innerHTML = `
        <a class="button button-outline" href="/login.html">
          เข้าสู่ระบบ
        </a>
      `;
    }
  } catch {
    target.innerHTML = `
      <a class="button button-outline" href="/login.html">
        เข้าสู่ระบบ
      </a>
    `;
  }
}

async function loadServers() {
  const list = document.querySelector('#server-list');
  if (!list) return;

  try {
    const response = await fetch('/api/servers');

    if (!response.ok) {
      throw new Error('โหลดแพ็กเกจไม่สำเร็จ');
    }

    const servers = await response.json();

    function render(items) {
      list.innerHTML = items.length
        ? items.map(server => `
          <article class="server-card">
            <div class="server-card-top">
              <span class="server-type">
                ${escapeHtml(server.category)}
              </span>
              <span class="availability">พร้อมให้เช่า</span>
            </div>

            <h3>${escapeHtml(server.name)}</h3>

            <p class="server-description">
              ${escapeHtml(
                server.description || 'แพ็กเกจ Server สำหรับงานทั่วไป'
              )}
            </p>

            <div class="spec-grid">
              <div>
                <span>CPU</span>
                <strong>${escapeHtml(server.cpu)}</strong>
              </div>

              <div>
                <span>RAM</span>
                <strong>${Number(server.ram_gb) || 0} GB</strong>
              </div>

              <div>
                <span>Storage</span>
                <strong>${Number(server.storage_gb) || 0} GB</strong>
              </div>
            </div>

            <div class="price-line">
              <strong>${money(server.price_per_day)}</strong>
              <span>/ วัน</span>
            </div>

            <form class="rent-form" data-server-id="${server.id}">
              <label>
                ระยะเวลาเช่า (วัน)
                <input
                  name="duration_days"
                  type="number"
                  min="1"
                  max="365"
                  value="30"
                  required
                >
              </label>

              <p class="estimated">
                รวมโดยประมาณ:
                ${money(Number(server.price_per_day) * 30)}
              </p>

              <button class="button button-full" type="submit">
                เพิ่มเข้าตะกร้า
              </button>

              <p class="form-message" role="status"></p>
            </form>
          </article>
        `).join('')
        : '<p>ไม่พบแพ็กเกจที่ตรงกับคำค้นหา</p>';

      list.querySelectorAll('.rent-form').forEach(form => {
        const daysInput = form.elements.duration_days;
        const message = form.querySelector('.form-message');
        const estimated = form.querySelector('.estimated');

        const server = items.find(
          item => String(item.id) === form.dataset.serverId
        );

        if (!server) return;

        function updateEstimate() {
          const days = Number(daysInput.value) || 0;
          const total = Number(server.price_per_day) * days;

          estimated.textContent =
            `รวมโดยประมาณ: ${money(total)}`;
        }

        daysInput.addEventListener('input', updateEstimate);

        
form.addEventListener('submit', async event => {
          event.preventDefault();
          const durationDays = Number(daysInput.value);
          if (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 365) {
            window.alert('กรุณาเลือกระยะเวลาเช่าระหว่าง 1–365 วัน');
            form.dataset.submitting = 'false';
            if (submitButton) submitButton.disabled = false;
            daysInput.focus();
            return;
          }
          try {
            const meResponse = await fetch('/api/me');
            if (!meResponse.ok) throw new Error('ตรวจสอบสถานะบัญชีไม่สำเร็จ');
            const me = await meResponse.json();
            if (!me.user) {
              const goLogin = await showCenteredConfirm({ title: 'กรุณาเข้าสู่ระบบ', message: 'คุณต้องเข้าสู่ระบบก่อนเพิ่ม Server ลงตะกร้า', confirmText: 'เข้าสู่ระบบ', cancelText: 'กลับไป' });
              if (goLogin) location.href = '/login.html';
              form.dataset.submitting = 'false';
              if (submitButton) submitButton.disabled = false;
              return;
            }
            // ขอคำยืนยันก่อนแก้ไขข้อมูลในตะกร้า
            const confirmed = await showCenteredConfirm({
              title: 'ยืนยันเพิ่มเข้าตะกร้า',
              message: `ต้องการเพิ่ม ${server.name} ลงในตะกร้าหรือไม่?\nระยะเวลาเช่า: ${durationDays} วัน\nยอดรวม: ${money(Number(server.price_per_day) * durationDays)}`, 
              confirmText: 'ยืนยันเพิ่ม',
              cancelText: 'ยกเลิก'
            });

            // ถ้าผู้ใช้กดยกเลิก ต้องไม่เพิ่มหรือเปลี่ยนจำนวนในตะกร้า
            if (!confirmed) {
              message.textContent = 'ยกเลิกการเพิ่มเข้าตะกร้าแล้ว';
              return;
            }

            const cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
            if (!Array.isArray(cart)) throw new Error('ข้อมูลตะกร้าไม่ถูกต้อง');
            const serverId = Number(form.dataset.serverId);
            const existing = cart.find(item => Number(item.server_id) === serverId && Number(item.duration_days) === durationDays);
            if (existing) existing.quantity = (Number(existing.quantity) || 1) + 1;
            else cart.push({ server_id: serverId, server_name: server.name, duration_days: durationDays, price_per_day: Number(server.price_per_day) || 0, quantity: 1, added_at: new Date().toISOString() });
            localStorage.setItem(CART_KEY, JSON.stringify(cart));
            updateCartCount();
            message.textContent = 'เพิ่ม Server ลงตะกร้าแล้ว';
          } catch (error) {
            await showCenteredConfirm({ title: 'เพิ่มเข้าตะกร้าไม่สำเร็จ', message: error.message || 'เกิดข้อผิดพลาด กรุณาลองใหม่', confirmText: 'ตกลง', cancelText: 'ปิด' });
          } finally {
            form.dataset.submitting = 'false';
            if (submitButton) submitButton.disabled = false;
          }
        });

      });
    }

    render(servers);

    const searchInput = document.querySelector('#search-input, #server-search');

    if (searchInput && !searchInput.dataset.bound) {
      searchInput.dataset.bound = 'true';

      searchInput.addEventListener('input', event => {
        const term = event.target.value.toLowerCase().trim();

        render(
          servers.filter(server =>
            `${server.name} ${server.category} ${server.cpu}`
              .toLowerCase()
              .includes(term)
          )
        );
      });
    }
  } catch {
    list.innerHTML = `
      <p class="error">
        โหลดข้อมูลไม่สำเร็จ กรุณาตรวจสอบการเชื่อมต่อฐานข้อมูล
      </p>
    `;
  }
}

// ตั้งค่าและควบคุมตัวเลือกสกุลเงิน
function setupCurrencySelector() {
  const currencySelect = document.querySelector('#currency-select, #currency-switch');
  if (!currencySelect) return;

  currencySelect.value = getCurrency();
  if (currencySelect.dataset.bound === 'true') return;
  currencySelect.dataset.bound = 'true';
  currencySelect.addEventListener('change', event => {
    const currency = event.target.value === 'USD' ? 'USD' : 'THB';
    localStorage.setItem('serverRentalCurrency', currency);
    loadServers();
  });
}

function initApp() {
  updateCartCount();
  setupCurrencySelector();
  loadAccount();
  loadServers();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
