const moneyAdmin = v => Number(v).toLocaleString('th-TH',{minimumFractionDigits:2,maximumFractionDigits:2});
async function adminFetch(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'ดำเนินการไม่สำเร็จ');
  return data;
}
async function loadAdmin() {
  const me = await adminFetch('/api/me');
  if (!me.user) { location.href='/login.html?message=กรุณาเข้าสู่ระบบ'; return; }
  if (me.user.role !== 'admin') { document.querySelector('main').innerHTML='<h1>ไม่มีสิทธิ์เข้าถึง</h1><p>หน้านี้สำหรับผู้ดูแลระบบเท่านั้น</p>'; return; }
  const account = document.querySelector('#account-area');
  account.innerHTML = `<span class="welcome-user">${String(me.user.name).replace(/[&<>"']/g,'')}</span><button class="button button-outline" id="logout-button">ออกจากระบบ</button>`;
  document.querySelector('#logout-button').onclick = async () => { await fetch('/api/logout',{method:'POST'}); location.href='/'; };
  await refreshTables();
}
async function refreshTables() {
  const servers = await adminFetch('/api/admin/servers');
  document.querySelector('#admin-server-list').innerHTML = `<table><thead><tr><th>ID</th><th>ชื่อ</th><th>ประเภท</th><th>CPU</th><th>RAM</th><th>Storage</th><th>ราคา/วัน</th><th>สถานะ</th><th>การจัดการ</th></tr></thead><tbody>${servers.map(s=>`<tr><td>${s.id}</td><td>${String(s.name).replace(/[&<>"']/g,'')}</td><td>${s.category}</td><td>${s.cpu}</td><td>${s.ram_gb} GB</td><td>${s.storage_gb} GB</td><td>฿${moneyAdmin(s.price_per_day)}</td><td>${s.is_available?'เปิด':'ปิด'}</td><td><button class="small-button" data-toggle="${s.id}" data-state="${s.is_available?0:1}">${s.is_available?'ปิดให้เช่า':'เปิดให้เช่า'}</button> <button class="small-button danger" data-delete="${s.id}">ลบ</button></td></tr>`).join('')}</tbody></table>`;
  document.querySelectorAll('[data-toggle]').forEach(btn => btn.onclick = async () => {
    const s=servers.find(x=>x.id===Number(btn.dataset.toggle));
    try { await adminFetch(`/api/admin/servers/${s.id}`,{method:'PUT',body:JSON.stringify({...s,is_available:Number(btn.dataset.state)===1})}); await refreshTables(); }
    catch(e){ alert(e.message); }
  });
  document.querySelectorAll('[data-delete]').forEach(btn => btn.onclick = async () => {
    if(!confirm('ยืนยันการลบหรือปิดการให้เช่า Server นี้?')) return;
    try { const d=await adminFetch(`/api/admin/servers/${btn.dataset.delete}`,{method:'DELETE'}); alert(d.message); await refreshTables(); }
    catch(e){ alert(e.message); }
  });
  const rentals = await adminFetch('/api/admin/rentals');
  document.querySelector('#admin-rental-list').innerHTML = rentals.length ? `<table><thead><tr><th>เลขที่</th><th>สมาชิก</th><th>อีเมล</th><th>Server</th><th>วัน</th><th>ราคา</th><th>สถานะ</th><th>เปลี่ยนสถานะ</th></tr></thead><tbody>${rentals.map(r=>`<tr><td>${r.id}</td><td>${String(r.customer_name).replace(/[&<>"']/g,'')}</td><td>${String(r.email).replace(/[&<>"']/g,'')}</td><td>${String(r.server_name).replace(/[&<>"']/g,'')}</td><td>${r.duration_days}</td><td>฿${moneyAdmin(r.total_price)}</td><td>${r.status}</td><td><select data-status="${r.id}"><option value="pending" ${r.status==='pending'?'selected':''}>รอตรวจสอบ</option><option value="active" ${r.status==='active'?'selected':''}>กำลังใช้งาน</option><option value="completed" ${r.status==='completed'?'selected':''}>เสร็จสิ้น</option><option value="cancelled" ${r.status==='cancelled'?'selected':''}>ยกเลิก</option></select></td></tr>`).join('')}</tbody></table>` : '<p class="empty-state">ยังไม่มีรายการเช่า</p>';
  document.querySelectorAll('[data-status]').forEach(select=>select.onchange=async()=>{try{await adminFetch(`/api/admin/rentals/${select.dataset.status}/status`,{method:'PATCH',body:JSON.stringify({status:select.value})});await refreshTables();}catch(e){alert(e.message);}});
}
document.querySelector('#server-form').addEventListener('submit', async e => {
  e.preventDefault(); const msg=document.querySelector('#admin-message');
  try { await adminFetch('/api/admin/servers',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target).entries()))}); msg.textContent='เพิ่ม Server สำเร็จ';msg.className='form-message success';e.target.reset();await refreshTables(); }
  catch(err){msg.textContent=err.message;msg.className='form-message error';}
});
loadAdmin().catch(err=>{document.querySelector('#admin-server-list').textContent=err.message;});
