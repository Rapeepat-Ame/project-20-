const formMessage = document.querySelector('#form-message');
const queryMessage = new URLSearchParams(location.search).get('message');
if (queryMessage && formMessage) formMessage.textContent = queryMessage;

async function submitAuth(form, endpoint) {
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(form).entries());
    formMessage.textContent = 'กำลังดำเนินการ...';
    formMessage.className = 'form-message';
    try {
      const response = await fetch(endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
      const data = await response.json();
      formMessage.textContent = data.message || 'ดำเนินการไม่สำเร็จ';
      formMessage.className = `form-message ${response.ok ? 'success' : 'error'}`;
      if (response.ok) setTimeout(() => location.href = '/', 700);
    } catch {
      formMessage.textContent = 'เชื่อมต่อระบบไม่ได้ กรุณาลองใหม่';
      formMessage.className = 'form-message error';
    }
  });
}
const loginForm = document.querySelector('#login-form');
const registerForm = document.querySelector('#register-form');
if (loginForm) submitAuth(loginForm, '/api/login');
if (registerForm) submitAuth(registerForm, '/api/register');
