require('dotenv').config();

const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/server_rental';
const MONGODB_DB = process.env.MONGODB_DB || 'server_rental';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-only-change-this-secret-before-use';
const SESSION_MAX_AGE = 1000 * 60 * 60 * 2;

const client = new MongoClient(MONGODB_URI);

let db;
let users;
let servers;
let rentals;
let payments;
let counters;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(session({
  name: 'server_rental_sid',
  secret: SESSION_SECRET,
  store: MongoStore.create({
    mongoUrl: MONGODB_URI,
    dbName: MONGODB_DB,
    collectionName: 'sessions',
    ttl: Math.floor(SESSION_MAX_AGE / 1000)
  }),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_MAX_AGE
  }
}));

app.use(express.static(path.join(__dirname, 'public')));

function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login.html?message=กรุณาเข้าสู่ระบบก่อน');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login.html?message=กรุณาเข้าสู่ระบบก่อน');
  }

  if (req.session.user.role !== 'admin') {
    return res.status(403).send('ไม่มีสิทธิ์เข้าถึงหน้านี้');
  }

  next();
}

function toServerJSON(server) {
  return {
    id: server.id,
    name: server.name,
    category: server.category,
    cpu: server.cpu,
    ram_gb: server.ram_gb,
    storage_gb: server.storage_gb,
    price_per_day: Number(server.price_per_day),
    description: server.description || '',
    is_available: Boolean(server.is_available),
    created_at: server.created_at
  };
}


function toRentalJSON(rental, serverName, customer) {
  const createdAt = rental.created_at
    ? new Date(rental.created_at)
    : null;

  // รองรับรายการเช่าเก่าที่ไม่มี expires_at
  const expiresAt = rental.expires_at
    ? new Date(rental.expires_at)
    : createdAt
      ? new Date(
          createdAt.getTime() +
          (Number(rental.duration_days) || 0) * 24 * 60 * 60 * 1000
        )
      : null;

  return {
    id: rental.id,
    user_id: rental.user_id,
    server_id: rental.server_id,
    server_name: serverName || 'Server ที่ถูกลบ',
    customer_name: customer?.name || '',
    email: customer?.email || '',
    duration_days: rental.duration_days,
    total_price: Number(rental.total_price),
    status: rental.status,
    payment_status: rental.payment_status || null,
    payment_method: rental.payment_method || null,
    payment_id: rental.payment_id || null,
    created_at: rental.created_at,
    expires_at: expiresAt
  };
}

async function nextSequence(name) {
  const result = await counters.findOneAndUpdate(
    { _id: name },
    { $inc: { seq: 1 } },
    { upsert: true, returnDocument: 'after' }
  );

  return result?.seq || 1;
}

async function syncCounter(name, collection) {
  const latest = await collection
    .find({}, { projection: { id: 1 } })
    .sort({ id: -1 })
    .limit(1)
    .next();

  const maxId = latest?.id || 0;

  await counters.updateOne(
    { _id: name },
    { $max: { seq: maxId } },
    { upsert: true }
  );
}

async function seedServers() {
  const defaultServers = [
    {
      id: 1,
      name: 'Starter VPS',
      category: 'VPS',
      cpu: '2 vCPU',
      ram_gb: 4,
      storage_gb: 80,
      price_per_day: 45,
      description: 'เหมาะสำหรับเว็บไซต์ขนาดเล็กและงานทดลอง',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 2,
      name: 'Business VPS',
      category: 'VPS',
      cpu: '4 vCPU',
      ram_gb: 8,
      storage_gb: 160,
      price_per_day: 89,
      description: 'เหมาะสำหรับเว็บไซต์ธุรกิจและผู้ใช้งานระดับกลาง',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 3,
      name: 'Compute Server',
      category: 'Dedicated',
      cpu: '8 Cores',
      ram_gb: 16,
      storage_gb: 500,
      price_per_day: 180,
      description: 'เหมาะสำหรับงานประมวลผลที่ใช้ทรัพยากรสูง',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 4,
      name: 'Basic VPS',
      category: 'VPS',
      cpu: '2 vCPU',
      ram_gb: 2,
      storage_gb: 50,
      price_per_day: 30,
      description: 'เหมาะสำหรับผู้เริ่มต้นและเว็บไซต์ส่วนตัว',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 5,
      name: 'Standard VPS',
      category: 'VPS',
      cpu: '4 vCPU',
      ram_gb: 8,
      storage_gb: 200,
      price_per_day: 75,
      description: 'เหมาะสำหรับเว็บไซต์ที่มีผู้เข้าชมต่อเนื่อง',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 6,
      name: 'Premium VPS',
      category: 'VPS',
      cpu: '8 vCPU',
      ram_gb: 16,
      storage_gb: 400,
      price_per_day: 150,
      description: 'เหมาะสำหรับระบบธุรกิจและแอปพลิเคชันขนาดใหญ่',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 7,
      name: 'Game Server',
      category: 'Game',
      cpu: '6 vCPU',
      ram_gb: 12,
      storage_gb: 150,
      price_per_day: 120,
      description: 'เหมาะสำหรับเซิร์ฟเวอร์เกมและกลุ่มผู้เล่น',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 8,
      name: 'Storage Server',
      category: 'Storage',
      cpu: '4 vCPU',
      ram_gb: 8,
      storage_gb: 1000,
      price_per_day: 110,
      description: 'เหมาะสำหรับจัดเก็บไฟล์และข้อมูลจำนวนมาก',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 9,
      name: 'Dedicated Pro',
      category: 'Dedicated',
      cpu: '16 Cores',
      ram_gb: 32,
      storage_gb: 1000,
      price_per_day: 350,
      description: 'เหมาะสำหรับระบบที่ต้องการทรัพยากรเฉพาะสูง',
      is_available: true,
      created_at: new Date()
    },
    {
      id: 10,
      name: 'GPU Compute',
      category: 'GPU',
      cpu: '16 vCPU',
      ram_gb: 32,
      storage_gb: 500,
      price_per_day: 600,
      description: 'แพ็กเกจจำลองสำหรับงานคำนวณประสิทธิภาพสูง',
      is_available: true,
      created_at: new Date()
    }
  ];

  for (const server of defaultServers) {
    await servers.updateOne(
      { id: server.id },
      { $setOnInsert: server },
      { upsert: true }
    );
  }

  await syncCounter('servers', servers);
}

app.get('/api/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

app.get('/api/servers', async (req, res, next) => {
  try {
    const rows = await servers
      .find({ is_available: true })
      .sort({ id: -1 })
      .toArray();

    res.json(rows.map(toServerJSON));
  } catch (err) {
    next(err);
  }
});

app.post('/api/register', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (
      name.length < 2 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      password.length < 8
    ) {
      return res.status(400).json({
        message: 'กรุณากรอกชื่อ อีเมลให้ถูกต้อง และรหัสผ่านอย่างน้อย 8 ตัวอักษร'
      });
    }

    if (await users.findOne({ email }, { projection: { id: 1 } })) {
      return res.status(409).json({ message: 'อีเมลนี้มีบัญชีแล้ว' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const user = {
      id: await nextSequence('users'),
      name,
      email,
      password_hash: passwordHash,
      role: 'member',
      created_at: new Date()
    };

    await users.insertOne(user);

    req.session.regenerate((err) => {
      if (err) return next(err);

      req.session.user = {
        id: user.id,
        name,
        email,
        role: 'member'
      };

      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);

        res.status(201).json({
          message: 'สมัครสมาชิกสำเร็จ',
          user: req.session.user
        });
      });
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'อีเมลนี้มีบัญชีแล้ว' });
    }

    next(err);
  }
});

app.post('/api/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    const user = await users.findOne({ email });

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({
        message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
      });
    }

    req.session.regenerate((err) => {
      if (err) return next(err);

      req.session.user = {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      };

      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);

        res.json({
          message: 'เข้าสู่ระบบสำเร็จ',
          user: req.session.user
        });
      });
    });
  } catch (err) {
    next(err);
  }
});

app.post('/api/logout', (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);

    res.clearCookie('server_rental_sid', {
      httpOnly: true,
      sameSite: 'lax'
    });

    res.json({ message: 'ออกจากระบบสำเร็จ' });
  });
});

// เริ่มรายการชำระเงินสาธิต: ยังไม่สร้างรายการเช่าจนกว่าจะยืนยันสำเร็จ
app.post('/api/payments/demo', requireLogin, async (req, res, next) => {
  try {
    const serverId = Number(req.body.server_id);
    const durationDays = Number(req.body.duration_days);

    if (
      !Number.isInteger(serverId) || serverId < 1 ||
      !Number.isInteger(durationDays) || durationDays < 1 || durationDays > 365
    ) {
      return res.status(400).json({
        message: 'กรุณาเลือก Server และระยะเวลาเช่า 1–365 วัน'
      });
    }

    const server = await servers.findOne({ id: serverId, is_available: true });
    if (!server) {
      return res.status(404).json({ message: 'ไม่พบ Server หรือ Server นี้ไม่พร้อมให้เช่า' });
    }

    const createdAt = new Date();
    const payment = {
      id: await nextSequence('payments'),
      user_id: req.session.user.id,
      server_id: serverId,
      server_name: server.name,
      duration_days: durationDays,
      total_price: Number((Number(server.price_per_day) * durationDays).toFixed(2)),
      status: 'pending',
      payment_method: null,
      rental_id: null,
      created_at: createdAt,
      expires_at: new Date(createdAt.getTime() + 15 * 60 * 1000)
    };

    await payments.insertOne(payment);
    res.status(201).json({
      message: 'สร้างรายการชำระเงินสาธิตแล้ว',
      payment_id: payment.id,
      total_price: payment.total_price
    });
  } catch (err) {
    next(err);
  }
});

// สร้างรายการชำระเงินสาธิตสำหรับการต่อเวลา (ยังไม่เปลี่ยนวันหมดอายุจนกว่าจะชำระสำเร็จ)
app.post('/api/my-rentals/:id/extend-payment', requireLogin, async (req, res, next) => {
  try {
    const rentalId = Number(req.params.id);
    const durationDays = Number(req.body.duration_days);
    if (!Number.isInteger(rentalId) || rentalId < 1 || !Number.isInteger(durationDays) || durationDays < 1 || durationDays > 3650) {
      return res.status(400).json({ message: 'ข้อมูลรายการหรือระยะเวลาต่ออายุไม่ถูกต้อง' });
    }

    const rental = await rentals.findOne({ id: rentalId, user_id: req.session.user.id });
    if (!rental) return res.status(404).json({ message: 'ไม่พบรายการเช่าของคุณ' });
    if (rental.status !== 'active') return res.status(400).json({ message: 'ต่อเวลาได้เฉพาะรายการที่กำลังใช้งาน' });

    const server = await servers.findOne({ id: rental.server_id, is_available: true });
    if (!server) return res.status(404).json({ message: 'ไม่พบ Server หรือ Server นี้ไม่พร้อมให้บริการ' });

    const createdAt = new Date();
    const payment = {
      id: await nextSequence('payments'),
      user_id: req.session.user.id,
      server_id: rental.server_id,
      server_name: server.name || rental.server_name || 'Server',
      duration_days: durationDays,
      total_price: Number((Number(server.price_per_day) * durationDays).toFixed(2)),
      status: 'pending',
      payment_method: null,
      rental_id: null,
      payment_type: 'extension',
      target_rental_id: rental.id,
      created_at: createdAt,
      expires_at: new Date(createdAt.getTime() + 15 * 60 * 1000)
    };
    await payments.insertOne(payment);
    res.status(201).json({ message: 'สร้างรายการชำระเงินต่อเวลาแล้ว', payment_id: payment.id, total_price: payment.total_price });
  } catch (err) { next(err); }
});

// อ่านรายละเอียดรายการชำระเงินของผู้ใช้ที่เข้าสู่ระบบเท่านั้น
app.get('/api/payments/:id', requireLogin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) {
      return res.status(400).json({ message: 'รหัสรายการชำระเงินไม่ถูกต้อง' });
    }

    const payment = await payments.findOne({ id, user_id: req.session.user.id });
    if (!payment) {
      return res.status(404).json({ message: 'ไม่พบรายการชำระเงินนี้' });
    }

    if (payment.status === 'pending' && payment.expires_at <= new Date()) {
      await payments.updateOne({ id, status: 'pending' }, { $set: { status: 'expired' } });
      payment.status = 'expired';
    }

    res.json({
      id: payment.id,
      server_id: payment.server_id,
      server_name: payment.server_name,
      duration_days: payment.duration_days,
      total_price: payment.total_price,
      status: payment.status,
      payment_method: payment.payment_method,
      rental_id: payment.rental_id,
      created_at: payment.created_at,
      expires_at: payment.expires_at
    });
  } catch (err) {
    next(err);
  }
});

// จำลองการชำระเงินสำเร็จเท่านั้น ไม่มีการตัดเงินจริงหรือเชื่อมต่อธนาคาร
app.post('/api/payments/:id/confirm-demo', requireLogin, async (req, res, next) => {
  let paymentId;
  let method;
  try {
    paymentId = Number(req.params.id);
    method = String(req.body.payment_method || '').toLowerCase();

    if (!Number.isInteger(paymentId) || paymentId < 1) {
      return res.status(400).json({ message: 'รหัสรายการชำระเงินไม่ถูกต้อง' });
    }
    if (!['paypal', 'mastercard'].includes(method)) {
      return res.status(400).json({ message: 'กรุณาเลือก PayPal หรือ Mastercard สำหรับการสาธิต' });
    }

    const existing = await payments.findOne({ id: paymentId, user_id: req.session.user.id });
    if (!existing) return res.status(404).json({ message: 'ไม่พบรายการชำระเงินนี้' });

    // ทำให้การกดซ้ำหลังสำเร็จไม่สร้างรายการเช่าซ้ำ
    if (existing.status === 'paid' && existing.rental_id) {
      return res.json({
        message: 'รายการนี้ชำระเงินสาธิตสำเร็จแล้ว',
        rental_id: existing.rental_id,
        already_paid: true
      });
    }
    if (existing.status !== 'pending') {
      return res.status(409).json({ message: 'รายการนี้ไม่อยู่ในสถานะที่ชำระเงินได้แล้ว' });
    }
    if (existing.expires_at <= new Date()) {
      await payments.updateOne({ id: paymentId, status: 'pending' }, { $set: { status: 'expired' } });
      return res.status(410).json({ message: 'รายการชำระเงินหมดอายุแล้ว กรุณาเลือกเช่าใหม่อีกครั้ง' });
    }

    const claimed = await payments.findOneAndUpdate(
      { id: paymentId, user_id: req.session.user.id, status: 'pending' },
      { $set: { status: 'processing', payment_method: method, processing_at: new Date() } },
      { returnDocument: 'after' }
    );
    const payment = claimed && claimed.id ? claimed : claimed?.value;
    if (!payment) {
      const latest = await payments.findOne({ id: paymentId, user_id: req.session.user.id });
      if (latest?.status === 'paid' && latest.rental_id) {
        return res.json({ message: 'รายการนี้ชำระเงินสาธิตสำเร็จแล้ว', rental_id: latest.rental_id, already_paid: true });
      }
      return res.status(409).json({ message: 'รายการนี้กำลังดำเนินการหรือไม่สามารถชำระเงินได้ กรุณาลองใหม่' });
    }

    try {
      // การชำระเงินต่อเวลา: เพิ่มวันและยอดเงินในรายการเดิมหลังยืนยันสำเร็จเท่านั้น
      if (payment.payment_type === 'extension') {
        const targetId = Number(payment.target_rental_id);
        const rental = await rentals.findOne({ id: targetId, user_id: payment.user_id, status: 'active' });
        if (!rental) throw new Error('ไม่พบรายการเช่าที่สามารถต่อเวลาได้');
        const oldExpiry = rental.expires_at ? new Date(rental.expires_at) : new Date();
        const baseTime = Math.max(oldExpiry.getTime(), Date.now());
        const newExpiry = new Date(baseTime + Number(payment.duration_days) * 24 * 60 * 60 * 1000);
        const additionalPrice = Number(payment.total_price) || 0;
        const updated = await rentals.updateOne(
          { id: targetId, user_id: payment.user_id, status: 'active' },
          { $inc: { duration_days: Number(payment.duration_days), total_price: additionalPrice },
            $set: { expires_at: newExpiry, updated_at: new Date(), payment_status: 'paid', payment_method: method } }
        );
        if (!updated.modifiedCount) throw new Error('ไม่สามารถต่อเวลาได้ กรุณาโหลดข้อมูลใหม่');
        await payments.updateOne(
          { id: paymentId, status: 'processing' },
          { $set: { status: 'paid', rental_id: targetId, paid_at: new Date(), payment_method: method } }
        );
        return res.json({ message: 'ชำระเงินสาธิตสำหรับการต่อเวลาสำเร็จ', rental_id: targetId, extended: true });
      }

      const existingRental = await rentals.findOne({ payment_id: payment.id });
      if (existingRental) {
        await payments.updateOne(
          { id: paymentId },
          { $set: { status: 'paid', rental_id: existingRental.id, paid_at: new Date(), payment_method: existingRental.payment_method || method } }
        );
        return res.json({ message: 'รายการนี้ชำระเงินสาธิตสำเร็จแล้ว', rental_id: existingRental.id, already_paid: true });
      }

      const server = await servers.findOne({ id: payment.server_id, is_available: true });
      if (!server) throw new Error('Server นี้ไม่พร้อมให้เช่าแล้ว กรุณายกเลิกรายการและเลือก Server ใหม่');

      const createdAt = new Date();
      const rental = {
        id: await nextSequence('rentals'),
        user_id: payment.user_id,
        server_id: payment.server_id,
        duration_days: payment.duration_days,
        total_price: payment.total_price,
        status: 'active',
        payment_status: 'paid',
        payment_method: method,
        payment_id: payment.id,
        created_at: createdAt,
        expires_at: new Date(createdAt.getTime() + payment.duration_days * 24 * 60 * 60 * 1000)
      };

      await rentals.insertOne(rental);
      await payments.updateOne(
        { id: paymentId, status: 'processing' },
        { $set: { status: 'paid', rental_id: rental.id, paid_at: new Date() } }
      );

      res.json({ message: 'ชำระเงินสาธิตสำเร็จและสร้างรายการเช่าแล้ว', rental_id: rental.id });
    } catch (err) {
      await payments.updateOne(
        { id: paymentId, status: 'processing' },
        { $set: { status: 'pending' }, $unset: { processing_at: '', payment_method: '' } }
      );
      if (err.message.includes('Server นี้ไม่พร้อม')) {
        return res.status(409).json({ message: err.message });
      }
      throw err;
    }
  } catch (err) {
    next(err);
  }
});

app.post('/api/payments/:id/cancel-demo', requireLogin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const result = await payments.updateOne(
      { id, user_id: req.session.user.id, status: 'pending' },
      { $set: { status: 'cancelled', cancelled_at: new Date() } }
    );
    if (!result.modifiedCount) {
      return res.status(409).json({ message: 'รายการนี้ถูกยกเลิก ชำระแล้ว หรือหมดอายุไปแล้ว' });
    }
    res.json({ message: 'ยกเลิกรายการชำระเงินแล้ว โดยไม่มีการสร้างรายการเช่า' });
  } catch (err) {
    next(err);
  }
});

// ป้องกัน endpoint เก่าที่สร้างรายการเช่าโดยไม่ผ่านขั้นตอนชำระเงิน
app.post('/api/rentals', requireLogin, (req, res) => {
  res.status(410).json({
    message: 'กรุณาเริ่มรายการจากหน้าเลือก Server และดำเนินการผ่านหน้าชำระเงินสาธิตก่อน'
  });
});

app.get('/api/my-rentals', requireLogin, async (req, res, next) => {
  try {
    const rows = await rentals
      .find({ user_id: req.session.user.id })
      .sort({ created_at: -1 })
      .toArray();

    const serverIds = [...new Set(rows.map(row => row.server_id))];

    const serverRows = await servers
      .find({ id: { $in: serverIds } })
      .toArray();

    const serverNames = new Map(
      serverRows.map(server => [server.id, server.name])
    );

    res.json(
      rows.map(row => toRentalJSON(row, serverNames.get(row.server_id)))
    );
  } catch (err) {
    next(err);
  }
});


/* =========================================
   สมาชิกยกเลิกรายการเช่าของตัวเอง
========================================= */
app.post(
  '/api/my-rentals/:id/cancel',
  requireLogin,
  async (req, res, next) => {
    try {
      const id = Number(req.params.id);

      if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({
          message: 'หมายเลขรายการเช่าไม่ถูกต้อง'
        });
      }

      // ค้นหาเฉพาะรายการของสมาชิกที่เข้าสู่ระบบ
      const rental = await rentals.findOne({
        id,
        user_id: req.session.user.id
      });

      if (!rental) {
        return res.status(404).json({
          message: 'ไม่พบรายการเช่าของคุณ'
        });
      }

      if (!['pending', 'active'].includes(rental.status)) {
        return res.status(400).json({
          message: 'รายการนี้ไม่สามารถยกเลิกได้'
        });
      }

      const now = new Date();

      const result = await rentals.updateOne(
        {
          id,
          user_id: req.session.user.id,
          status: rental.status
        },
        {
          $set: {
            status: 'cancelled',
            cancelled_at: now,
            updated_at: now
          }
        }
      );

      if (!result.modifiedCount) {
        return res.status(409).json({
          message: 'สถานะรายการเปลี่ยนไปแล้ว กรุณาโหลดข้อมูลใหม่'
        });
      }

      return res.json({
        message: 'ยกเลิกการเช่าสำเร็จ'
      });
    } catch (err) {
      next(err);
    }
  }
);


/* =========================================
   สมาชิกต่อเวลารายการเช่าของตัวเอง
========================================= */
app.post(
  '/api/my-rentals/:id/extend',
  requireLogin,
  async (req, res, next) => {
    try {
      const id = Number(req.params.id);
      const durationDays = Number(req.body.duration_days);

      if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({
          message: 'หมายเลขรายการเช่าไม่ถูกต้อง'
        });
      }

      // อนุญาตให้ระบุจำนวนวันเอง ตั้งแต่ 1 ถึง 3650 วัน
      if (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 3650) {
        return res.status(400).json({
          message: 'กรุณากรอกจำนวนวันตั้งแต่ 1 ถึง 3650 วัน'
        });
      }

      const userId = req.session.user.id;

      // ตรวจสอบว่าเป็นรายการของสมาชิกคนนี้
      const rental = await rentals.findOne({
        id,
        user_id: userId
      });

      if (!rental) {
        return res.status(404).json({
          message: 'ไม่พบรายการเช่าของคุณ'
        });
      }

      if (rental.status !== 'active') {
        return res.status(400).json({
          message: 'ต่อเวลาได้เฉพาะรายการที่กำลังใช้งาน'
        });
      }

      const server = await servers.findOne({
        id: rental.server_id
      });

      if (!server) {
        return res.status(404).json({
          message: 'ไม่พบข้อมูล Server ของรายการนี้'
        });
      }

      // คำนวณค่าใช้จ่ายเฉพาะวันที่ต่อเพิ่ม
      const additionalPrice = Number(
        (Number(server.price_per_day) * durationDays).toFixed(2)
      );

      // รองรับรายการเก่าที่ไม่มี expires_at
      const oldExpiry = rental.expires_at
        ? new Date(rental.expires_at)
        : new Date(
            new Date(rental.created_at).getTime() +
            (Number(rental.duration_days) || 0) *
              24 * 60 * 60 * 1000
          );

      // ถ้ายังไม่หมดอายุ ให้ต่อจากวันหมดอายุเดิม
      // ถ้าหมดอายุแล้ว ให้เริ่มนับจากเวลาปัจจุบัน
      const baseTime = Math.max(
        oldExpiry.getTime(),
        Date.now()
      );

      const newExpiry = new Date(
        baseTime + durationDays * 24 * 60 * 60 * 1000
      );

      const now = new Date();

      const result = await rentals.updateOne(
        {
          id,
          user_id: userId,
          status: 'active'
        },
        {
          $inc: {
            duration_days: durationDays,
            total_price: additionalPrice
          },
          $set: {
            expires_at: newExpiry,
            updated_at: now
          }
        }
      );

      if (!result.modifiedCount) {
        return res.status(409).json({
          message: 'ไม่สามารถต่อเวลาได้ กรุณาโหลดข้อมูลใหม่'
        });
      }

      return res.json({
        message: 'ต่อเวลาการเช่าสำเร็จ',
        additional_price: additionalPrice,
        duration_days: durationDays,
        expires_at: newExpiry
      });
    } catch (err) {
      next(err);
    }
  }
);


app.get('/api/admin/servers', requireAdmin, async (req, res, next) => {
  try {
    const rows = await servers.find({}).sort({ id: -1 }).toArray();
    res.json(rows.map(toServerJSON));
  } catch (err) {
    next(err);
  }
});

app.post('/api/admin/servers', requireAdmin, async (req, res, next) => {
  try {
    const {
      name,
      category,
      cpu,
      ram_gb,
      storage_gb,
      price_per_day,
      description
    } = req.body;

    if (
      !String(name || '').trim() ||
      !String(category || '').trim() ||
      !String(cpu || '').trim() ||
      !Number.isInteger(Number(ram_gb)) ||
      Number(ram_gb) < 1 ||
      !Number.isInteger(Number(storage_gb)) ||
      Number(storage_gb) < 1 ||
      !Number.isFinite(Number(price_per_day)) ||
      Number(price_per_day) < 0
    ) {
      return res.status(400).json({ message: 'ข้อมูล Server ไม่ถูกต้อง' });
    }

    const server = {
      id: await nextSequence('servers'),
      name: String(name).trim(),
      category: String(category).trim(),
      cpu: String(cpu).trim(),
      ram_gb: Number(ram_gb),
      storage_gb: Number(storage_gb),
      price_per_day: Number(price_per_day),
      description: String(description || '').trim(),
      is_available: true,
      created_at: new Date()
    };

    await servers.insertOne(server);

    res.status(201).json({
      message: 'เพิ่ม Server สำเร็จ',
      id: server.id
    });
  } catch (err) {
    next(err);
  }
});

app.put('/api/admin/servers/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);

    const {
      name,
      category,
      cpu,
      ram_gb,
      storage_gb,
      price_per_day,
      description,
      is_available
    } = req.body;

    if (
      !Number.isInteger(id) ||
      id < 1 ||
      !String(name || '').trim() ||
      !String(category || '').trim() ||
      !String(cpu || '').trim() ||
      !Number.isInteger(Number(ram_gb)) ||
      Number(ram_gb) < 1 ||
      !Number.isInteger(Number(storage_gb)) ||
      Number(storage_gb) < 1 ||
      !Number.isFinite(Number(price_per_day)) ||
      Number(price_per_day) < 0
    ) {
      return res.status(400).json({ message: 'ข้อมูล Server ไม่ถูกต้อง' });
    }

    const available =
      is_available === true ||
      is_available === 'true' ||
      is_available === 1 ||
      is_available === '1';

    const result = await servers.updateOne(
      { id },
      {
        $set: {
          name: String(name).trim(),
          category: String(category).trim(),
          cpu: String(cpu).trim(),
          ram_gb: Number(ram_gb),
          storage_gb: Number(storage_gb),
          price_per_day: Number(price_per_day),
          description: String(description || '').trim(),
          is_available: available
        }
      }
    );

    if (!result.matchedCount) {
      return res.status(404).json({ message: 'ไม่พบ Server' });
    }

    res.json({ message: 'แก้ไขข้อมูล Server สำเร็จ' });
  } catch (err) {
    next(err);
  }
});

app.delete('/api/admin/servers/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
      return res.status(400).json({ message: 'รหัส Server ไม่ถูกต้อง' });
    }

    if (await rentals.findOne({ server_id: id }, { projection: { id: 1 } })) {
      await servers.updateOne(
        { id },
        { $set: { is_available: false } }
      );

      return res.json({
        message: 'Server มีประวัติการเช่า จึงปิดการให้เช่าแทนการลบ'
      });
    }

    const result = await servers.deleteOne({ id });

    if (!result.deletedCount) {
      return res.status(404).json({ message: 'ไม่พบ Server' });
    }

    res.json({ message: 'ลบ Server สำเร็จ' });
  } catch (err) {
    next(err);
  }
});

app.get('/api/admin/rentals', requireAdmin, async (req, res, next) => {
  try {
    const rows = await rentals.find({})
      .sort({ created_at: -1 })
      .toArray();

    const userIds = [...new Set(rows.map(row => row.user_id))];
    const serverIds = [...new Set(rows.map(row => row.server_id))];

    const [userRows, serverRows] = await Promise.all([
      users.find(
        { id: { $in: userIds } },
        { projection: { id: 1, name: 1, email: 1 } }
      ).toArray(),

      servers.find(
        { id: { $in: serverIds } },
        { projection: { id: 1, name: 1 } }
      ).toArray()
    ]);

    const userMap = new Map(userRows.map(user => [user.id, user]));
    const serverMap = new Map(serverRows.map(server => [server.id, server.name]));

    res.json(
      rows.map(row =>
        toRentalJSON(
          row,
          serverMap.get(row.server_id),
          userMap.get(row.user_id)
        )
      )
    );
  } catch (err) {
    next(err);
  }
});

app.patch('/api/admin/rentals/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const allowed = ['pending', 'active', 'completed', 'cancelled'];
    const status = String(req.body.status || '');
    const id = Number(req.params.id);

    if (!allowed.includes(status)) {
      return res.status(400).json({ message: 'สถานะไม่ถูกต้อง' });
    }

    if (!Number.isInteger(id) || id < 1) {
      return res.status(400).json({ message: 'เลขที่รายการเช่าไม่ถูกต้อง' });
    }

    const result = await rentals.updateOne(
      { id },
      { $set: { status } }
    );

    if (!result.matchedCount) {
      return res.status(404).json({ message: 'ไม่พบรายการเช่า' });
    }

    res.json({ message: 'ปรับสถานะรายการเช่าสำเร็จ' });
  } catch (err) {
    next(err);
  }
});

app.get('/api/health', async (req, res) => {
  try {
    await db.command({ ping: 1 });
    res.json({ ok: true, database: 'connected', name: MONGODB_DB });
  } catch {
    res.status(503).json({ ok: false, database: 'disconnected' });
  }
});

app.use((err, req, res, next) => {
  console.error(err);

  if (res.headersSent) {
    return next(err);
  }

  res.status(500).json({
    message: 'เกิดข้อผิดพลาดภายในระบบ กรุณาตรวจสอบ Terminal'
  });
});

async function start() {
  try {
    await client.connect();

    db = client.db(MONGODB_DB);
    users = db.collection('users');
    servers = db.collection('servers');
    rentals = db.collection('rentals');
    payments = db.collection('payments');
    counters = db.collection('counters');

    await Promise.all([
      users.createIndex({ email: 1 }, { unique: true }),
      servers.createIndex({ id: 1 }, { unique: true }),
      rentals.createIndex({ id: 1 }, { unique: true }),
      rentals.createIndex({ user_id: 1, created_at: -1 }),
      rentals.createIndex({ server_id: 1 }),
      rentals.createIndex({ payment_id: 1 }, { unique: true, sparse: true }),
      payments.createIndex({ id: 1 }, { unique: true }),
      payments.createIndex({ user_id: 1, created_at: -1 }),
      payments.createIndex({ status: 1, expires_at: 1 })
    ]);

    await seedServers();

    await Promise.all([
      syncCounter('users', users),
      syncCounter('rentals', rentals),
      syncCounter('payments', payments)
    ]);

    app.listen(PORT, () => {
      console.log(`ระบบเช่า Server เปิดที่ http://localhost:${PORT}`);
      console.log(`เชื่อมต่อ MongoDB สำเร็จ: ${MONGODB_DB}`);
    });
  } catch (err) {
    console.error(
      'เชื่อมต่อ MongoDB ไม่สำเร็จ ตรวจสอบว่า MongoDB Service ทำงานอยู่และค่า MONGODB_URI ถูกต้อง'
    );
    console.error(err.message);
    process.exit(1);
  }
}

start();